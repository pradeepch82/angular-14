import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit {

  constructor() { 
    console.log("--------TechnologiesComponent created-----------");
  
    
    }
  
    ngOnInit(): void {
      console.log("--------TechnologiesComponent initialized-----------");
    }
    
    
    ngOnDestroy(): void {
      console.log("--------TechnologiesComponent destroyed-----------");
      
    }
  

}
