import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  title="All Users";

  users:any;
  
  message="";
  
  userId=0;
  
  user:any;

    constructor(private us:UsersService,private route:ActivatedRoute) { 
      console.log("--------UsersComponent created-----------");
    
      
      }
    
      ngOnInit(): void {
        console.log("--------UsersComponent initialized-----------");
  
this.userId=this.route.snapshot.params['userId'];


if(this.userId)
 this.getUserById();
  
      }
      
      
      ngOnDestroy(): void {
        console.log("--------UsersComponent destroyed-----------");
        
      }
  
  
  
      getUserById(){
  
        this.us.getUserById(this.userId)
               .subscribe(response=>{this.user=response;
                            console.log("Got User data");
                            this.title=`${this.user.username}  Details`;
                              
                          },
                          error=>{this.message=error;
                          console.log("Problme In Getting the user");
                          });  
      }
  

}
