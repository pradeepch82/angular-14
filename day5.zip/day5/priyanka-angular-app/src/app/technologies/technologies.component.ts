import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent implements OnInit {


  title="Top 5 Technologies";   //string


  technologies=[
    {id:101,name:'Angular',likes:0,dislikes:0},
    {id:102,name:'React.js',likes:0,dislikes:0},
    {id:103,name:'AWS',likes:0,dislikes:0},
    {id:104,name:'Microservices',likes:0,dislikes:0},
    {id:105,name:'.Net',likes:0,dislikes:0},
  ];  //array



  constructor() { 
    console.log("--------TechnologiesComponent created-----------");
  
    
    }
  
    ngOnInit(): void {
      console.log("--------TechnologiesComponent initialized-----------");
    }
    
    
    ngOnDestroy(): void {
      console.log("--------TechnologiesComponent destroyed-----------");
      
    }
  


    incrementDislikes(t){
      t.dislikes++;
    }


    incrementLikes(t){
      t.likes++;
    }

}
