import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[bgColor]'
})
export class BgColorDirective {

  constructor(private e:ElementRef,private r:Renderer2) { 
    console.log("-------BgColorDirective created----------");
  }
  @Input()
  set bgColor(color:string){
  console.log("In setBgColor  "+color);
  this.r.setStyle(this.e.nativeElement,'background-color',color);
  }


}
