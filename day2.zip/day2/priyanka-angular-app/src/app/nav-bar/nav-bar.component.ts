import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor() { 
    console.log("--------NavBarComponent created-----------");
  
    
    }
  
    ngOnInit(): void {
      console.log("--------NavBarComponent initialized-----------");
    }
    
    
    ngOnDestroy(): void {
      console.log("--------NavBarComponent destroyed-----------");
      
    }
}
