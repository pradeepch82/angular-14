import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //where to inject
  templateUrl: './app.component.html', //where to display
  template:`
  <h2> Hi </h2>
  <h2> Hi </h2>
  <h2> Hi </h2> 
  <h2> Hi </h2>
  <h2> Hi </h2> <h2> Hi </h2>
  `, // if code is < 4 line
  styleUrls: ['./app.component.css']    //how to display
})
export class AppComponent {
  title = 'priyanka-angular-app'; // what to dsiplay
}
