import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { BgColorDirective } from '../directives/bg-color.directive';
import { FgColorDirective } from '../directives/fg-color.directive';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-view-child',
  templateUrl: './view-child.component.html',
  styleUrls: ['./view-child.component.css']
})
export class ViewChildComponent implements OnInit {

@ViewChild(NumberComponent)
 nc:NumberComponent;
  
@ViewChild(FgColorDirective)
 f:FgColorDirective;

 @ViewChild(BgColorDirective)
 b:BgColorDirective;

@ViewChild("name")
 name:ElementRef;

@ViewChild("city")
 city:ElementRef;


  constructor() { }

  ngOnInit(): void {
  }



  increment(){
    this.nc.increment();
  }

  decrement(){
    this.nc.decrement();
  }

changeColors(){
this.f.fgColor='red';
this.b.bgColor='grey';

}


changeFgBgColor(){
  this.name.nativeElement.style.color="RED";
  this.name.nativeElement.style.backgroundColor="yellow";
  
  this.city.nativeElement.style.color="brown";
  this.city.nativeElement.style.backgroundColor="wheat";

}

}
