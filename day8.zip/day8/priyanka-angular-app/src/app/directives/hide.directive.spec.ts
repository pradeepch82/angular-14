import { HideDirective } from './hide.directive';

describe('HideDirective', () => {
  it('should create an instance', () => {
    const directive = new HideDirective();
    expect(directive).toBeTruthy();
  });
});
