import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MultiGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {


constructor(private router:Router){
console.log("..............MultiGuard Service created...........");
}


  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      
    let email=sessionStorage.getItem("email");
    
    if(email==null ||email=='undefined')
    {
      alert("Plz Login First");
      this.router.navigate(['/login']);
      return false;
    }
    {
     //alert("Login succesfull.."); 
      return true;
    }
  }
  
  
  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      let email=sessionStorage.getItem("email");
    
      if(email!='pradeep@gmail.com')
      {
        alert("You are not authorized to visit this section,Login with other credentails");
        this.router.navigate(['/login']);
        return false;
      }
      {
       //alert("Login succesfull.."); 
        return true;
      } }
  
  
  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return confirm("Do you want to Leave this page?");

  }


  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
           return confirm("Do you want to load the module?");
     }

}
