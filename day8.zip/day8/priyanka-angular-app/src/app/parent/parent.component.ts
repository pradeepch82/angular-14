import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {



  message="Parent Message";

  childMessage="";


  constructor() { 
    console.log("--------ParentComponent created-----------");
  
    
    }
  
    ngOnInit(): void {
      console.log("--------ParentComponent initialized-----------");
    }
    
    
    ngOnDestroy(): void {
      console.log("--------ParentComponent destroyed-----------");
      
    }

    
    ngOnChanges() {
      console.log("--------ParentComponent ngOnChanges -----------");
    }
    
    ngAfterContentInit() {
      console.log("--------ParentComponent ngAfterContentInit-----------");
    }
    
    ngAfterContentChecked() {
      console.log("--------ParentComponent ngAfterContentChecked -----------");
    }
    
    ngAfterViewChecked() {
      console.log("--------ParentComponent ngAfterViewChecked -----------");
    }
    
    ngAfterViewInit() {
      console.log("--------ParentComponent ngAfterViewInit -----------");
    }
  
  

    setChildMessage(value){
     this.childMessage=value; 
    }

}
