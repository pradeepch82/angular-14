import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';

const routes: Routes = [
  {path:"home",component:HomeComponent},
  {path:"technologies",component:TechnologiesComponent},
  {path:"basics",component:AngularBasicsComponent},
  {path:"pipes",component:AngularPipesComponent},
  
  {path:"**",redirectTo:"home"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
