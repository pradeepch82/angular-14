import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent {

title='Angular Basics'; //string

colors=['RED','GREEN','BLUE']; //array

day=4; //number
min:number=1;
max:number=8;

show=true; // boolean
hide:boolean=false; //boolean

employee={
   id:101,
   name:'Pradeep chinchole',
   salary:1244433.43536623423,
   variable:0.15,
   doj:new Date(),
   gender:'Male',
   age:40,
   isMarried:true,
   mobile:'9158652627',
   pan:'PMxpc9834D',
   city:'Pune'
};//object


time=new Observable<string>((s:Subscriber<string>)=>{
  setInterval(()=>{
    s.next(new Date().toLocaleString());
  },1000);
});



  constructor() { 
    console.log("--------AngularBasicsComponent created-----------");
  
    
    }
  
    ngOnInit(): void {
      console.log("--------AngularBasicsComponent initialized-----------");
    }
    
    
    ngOnDestroy(): void {
      console.log("--------AngularBasicsComponent destroyed-----------");
      
    }
    showHide(){
      this.hide=!this.hide;
    }
}
