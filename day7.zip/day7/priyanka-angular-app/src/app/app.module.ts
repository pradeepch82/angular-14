import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { MainComponent } from './main/main.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { GenderPipe } from './pipes/gender.pipe';
import { SortPipe } from './pipes/sort.pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { UsersComponent } from './users/users.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { PostsComponent } from './posts/posts.component';
import { CommentsComponent } from './comments/comments.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { TodosComponent } from './todos/todos.component';
import { HttpClientModule } from '@angular/common/http';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { NestedComponent } from './nested/nested.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { UsersService } from './services/users.service';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { MustMatchDirective } from './directives/must-match.directive';
import { AddressModule } from './address/address.module';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AngularBasicsComponent,
    TechnologiesComponent,
    HeaderComponent,
    FooterComponent,
    NavBarComponent,
    MainComponent,
    AngularPipesComponent,
    GenderPipe,
    SortPipe,
    UsersComponent,
    UsersListComponent,
    UsersTableComponent,
    PostsComponent,
    CommentsComponent,
    AlbumsComponent,
    PhotosComponent,
    CaseStudyComponent,
    TodosComponent,
    CustomDirectivesComponent,
    NestedComponent,
    ParentComponent,
    ChildComponent,
    FgColorDirective,
    BgColorDirective,
    ShowDirective,
    HideDirective,
    RegisterComponent,
    LoginComponent,
    MustMatchDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ReactiveFormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
