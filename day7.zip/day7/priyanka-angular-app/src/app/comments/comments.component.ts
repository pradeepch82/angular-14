import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';
import { CommentsService } from '../services/comments.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  
  title="All Comments";

  comments:any;

  message="";


  constructor(private cs:CommentsService,private route:ActivatedRoute) { 
    console.log("--------CommentsComponent created-----------");
      
    }
  
    ngOnInit(): void {
  
        let postId=this.route.snapshot.queryParams['postId'];

        if(postId)
        this.getCommnetsByPostId(postId);
        else
        this.getAllComments();
  

  
      console.log("--------CommentsComponent initialized-----------"+postId);
    }
    
    
    ngOnDestroy(): void {
      console.log("--------CommentsComponent destroyed-----------");
      
    }


    getAllComments(){

      this.cs.getAllComments()
             .subscribe(response=>this.comments=response,
                         error=>this.message=error);  
    }

    getCommnetsByPostId(postId:number){

      this.cs.getCommentsByPostId(postId)
             .subscribe(response=>this.comments=response,
                         error=>this.message=error);  
    }



  }
