import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[hide]'
})
export class HideDirective {

  
  constructor(private t:TemplateRef<any>,private vcr:ViewContainerRef) {
    console.log("----------------ShowDirective created---------");
  }


  @Input()
  set hide(value:boolean){
    console.log("----------------In setHide "+value);
     if(!value)
       this.vcr.createEmbeddedView(this.t);
       else
     this.vcr.clear();
 }

}
