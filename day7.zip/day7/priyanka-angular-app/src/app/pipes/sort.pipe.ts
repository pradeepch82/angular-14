import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class SortPipe implements PipeTransform {

  transform(array: any[], field:string='id',descending?:boolean): any[] {


          var datatype=typeof(array[0][field]);
          console.log("Datatype  :"+datatype);

          if(datatype=='number') //id,salary,variable,age
          array.sort((e1,e2)=>e1[field]-e2[field]);
          else if(datatype=='string') //name,pan,mobile,city
          array.sort((e1,e2)=>e1[field].localeCompare(e2[field]));
          else if(datatype=='object') //doj
          array.sort((e1,e2)=>e1[field].getTimemiilies()-e2[field].getTimemiilies());
              

          if(descending)
          array.reverse();

    return array;
  }

}
