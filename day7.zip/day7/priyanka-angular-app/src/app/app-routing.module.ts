import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlbumsComponent } from './albums/albums.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CommentsComponent } from './comments/comments.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { MultiGuard } from './guards/multi.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NestedComponent } from './nested/nested.component';
import { PhotosComponent } from './photos/photos.component';
import { PostsComponent } from './posts/posts.component';
import { RegisterComponent } from './register/register.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { TodosComponent } from './todos/todos.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  {path:"home",component:HomeComponent,canActivate:[MultiGuard]},
  {path:"technologies",component:TechnologiesComponent,canActivate:[MultiGuard],canDeactivate:[MultiGuard]},
  {path:"basics",component:AngularBasicsComponent,canActivate:[MultiGuard],canDeactivate:[MultiGuard]},
  {path:"pipes",component:AngularPipesComponent,canActivate:[MultiGuard]},
  {path:"custom-directives",component:CustomDirectivesComponent,canActivate:[MultiGuard]},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},


  {path:"nested",component:NestedComponent},
  
  {path:"case-study",component:CaseStudyComponent,canActivateChild:[MultiGuard],


  children:[
    {path:"users",component:UsersComponent,
 
  children:[
    {path:"list",component:UsersListComponent},
    {path:"table",component:UsersTableComponent}
  ]
  },
  {path:"users/:userId",component:UsersComponent},
  {path:"posts",component:PostsComponent},
    {path:"comments",component:CommentsComponent},
    {path:"todos",component:TodosComponent},
    {path:"albums",component:AlbumsComponent},
    {path:"photos",component:PhotosComponent},
  ]
},
{path:'address',loadChildren:()=>import('./address/address.module').then(mod=>mod.AddressModule),canLoad:[MultiGuard]},
  


  {path:"**",redirectTo:"home"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

  constructor(){
    console.log("............AppRoutingModule created.........");
    
  }
}
