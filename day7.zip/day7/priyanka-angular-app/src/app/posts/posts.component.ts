import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../services/posts.service';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

title="All Posts";

posts:any;

message="";


  constructor(private ps:PostsService,private route:ActivatedRoute) { 
    console.log("--------PostsComponent created-----------");
     
    }
  
    ngOnInit(): void {
  
       let userId= this.route.snapshot.queryParams['userId'];
              
        console.log("--------PostsComponent initialized-----------"+userId);

           if(userId)
           this.getPostsByUserId(userId);
           else
           this.getAllPosts();

    }
    
    
    ngOnDestroy(): void {
      console.log("--------PostsComponent destroyed-----------");
      
    }



    getAllPosts(){

      this.ps.getAllPosts()
             .subscribe(response=>{this.posts=response;
                          console.log("Got All Posts");
                          
                        },
                        error=>{this.message=error;
                        console.log("Problme In Invoking Service");
                        });  
    }

    getPostsByUserId(userId:number){

this.ps.getPostsByUserId(userId)
    .subscribe(response=>this.posts=response,
               error=>this.message=error);

    }

}
